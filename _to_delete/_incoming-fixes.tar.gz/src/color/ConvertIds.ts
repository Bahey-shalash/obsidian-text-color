import { isLiteralColor } from "src/color/InlineColor";
import { OPEN, openMarkerFor, tokenOf } from "src/syntax";

export interface ConversionResult {
	text: string;
	/** ids rewritten to their hex */
	converted: number;
	/** id tokens left untouched (the name resolves to nothing) */
	skipped: number;
}

/**
 * Rewrite every ~={id} prefix in the text to ~={#hex}, leaving everything else
 * byte for byte identical. Pure: the resolver decides what an id means.
 *
 * The resolver only ever answers with a canonical hex, so `skipped` means one
 * thing — the name is unknown — and the notice that reports it is true.
 */
export function convertIdsToHex(text: string, resolve: (id: string) => string | null): ConversionResult {
	let converted = 0;
	let skipped = 0;

	const out = text.replace(new RegExp(OPEN.source, "g"), (match) => {
		const token = tokenOf(match);

		if (isLiteralColor(token)) {
			return match; // already a hex literal
		}

		const hex = resolve(token);
		if (hex == null) {
			skipped++;
			return match;
		}

		converted++;
		return openMarkerFor(hex.toLowerCase());
	});

	return { text: out, converted, skipped };
}
