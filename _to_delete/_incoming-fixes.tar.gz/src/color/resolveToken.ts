import type { FastTextColorPluginSettings } from "src/settings/settings";
import { isLiteralColor, parseHex } from "src/color/InlineColor";

/**
 * What a markup token means: a hex literal is itself, a palette name or a
 * legacy id resolves through the settings, anything else is not a color.
 *
 * The answer is always a canonical hex or null. Settings are normalized on
 * load, and this second gate means even a hand edited data.json cannot get a
 * non-color into a style attribute.
 */
export function resolveTokenHex(token: string, settings: FastTextColorPluginSettings): string | null {
	if (isLiteralColor(token)) {
		return token.toLowerCase();
	}
	const configured = settings.palette.find(c => c.name === token)?.hex ?? settings.legacy[token];
	return configured == undefined ? null : parseHex(configured);
}

/** Resolver over the configured colors: palette names first, then legacy ids. */
export function makeIdResolver(settings: FastTextColorPluginSettings): (id: string) => string | null {
	return (id: string) => resolveTokenHex(id, settings);
}
