import { App, ColorComponent, Editor, Modal, Setting, TextComponent } from "obsidian";
import { insertColor } from "src/editor/TextColorFunctions";
import { parseHex, toPickerHex, normalizeHex } from "src/color/InlineColor";
import { colorStyle } from "src/color/ColorStyle";

/**
 * Modal that lets the user pick an arbitrary color and apply it directly as a
 * literal color in the markup (~={#rrggbb}text=~), without having to define it
 * as a named color in the palette first.
 */
export class CustomColorModal extends Modal {
	editor: Editor;
	hex: string;
	onPicked?: (hex: string) => void;

	private preview!: HTMLElement;
	private text!: TextComponent;
	private picker!: ColorComponent;
	private syncing = false;

	constructor(app: App, editor: Editor, initial = "#ff0000", onPicked?: (hex: string) => void) {
		super(app);
		this.editor = editor;
		this.hex = normalizeHex(initial);
		this.onPicked = onPicked;
	}

	onOpen(): void {
		const { contentEl } = this;
		contentEl.addClass("ftc-custom-color-modal");
		contentEl.createEl("h3", { text: "Custom color" });

		this.preview = contentEl.createEl("div", { cls: "ftc-custom-color-preview" });
		this.preview.setText(this.sampleText());

		new Setting(contentEl)
			.setName("Color")
			.addColorPicker(picker => {
				this.picker = picker;
				picker.setValue(toPickerHex(this.hex));
				picker.onChange(value => this.setHex(value, "picker"));
			})
			.addText(text => {
				this.text = text;
				text.setPlaceholder("#ff0000")
					.setValue(this.hex)
					.onChange(value => {
						if (parseHex(value) != null) {
							this.setHex(value, "text");
						}
					});
				text.inputEl.addEventListener("keydown", evt => {
					if (evt.key === "Enter") {
						evt.preventDefault();
						this.apply();
					}
				});
			});

		new Setting(contentEl)
			.addButton(btn => btn
				.setButtonText("Apply")
				.setCta()
				.onClick(() => this.apply()));

		this.updatePreview();
		// the modal may live in a pop out window; use that window's timer.
		activeWindow.setTimeout(() => this.text?.inputEl.focus(), 0);
	}

	onClose(): void {
		this.contentEl.empty();
	}

	private sampleText(): string {
		const selected = this.editor.getSelection();
		if (!selected) {
			return "This is colored text";
		}
		return selected.length > 80 ? `${selected.slice(0, 80)}...` : selected;
	}

	/**
	 * Keep the picker and the text field in sync without looping back on each other.
	 */
	private setHex(value: string, source: "picker" | "text") {
		if (this.syncing) {
			return;
		}
		this.hex = normalizeHex(value);

		this.syncing = true;
		try {
			if (source === "picker") {
				this.text?.setValue(this.hex);
			} else {
				this.picker?.setValue(toPickerHex(this.hex));
			}
		} finally {
			this.syncing = false;
		}

		this.updatePreview();
	}

	private updatePreview() {
		this.preview.setAttribute("style", colorStyle(this.hex));
	}

	private apply() {
		const hex = parseHex(this.hex);
		if (hex == null) {
			return;
		}
		insertColor(hex, this.editor);
		this.onPicked?.(hex);
		this.close();
	}
}
