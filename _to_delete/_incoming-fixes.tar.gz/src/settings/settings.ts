import { parseHex } from "src/color/InlineColor";
import type { ColorEnvironment } from "src/settings/colorEnvironment";

export const SETTINGS_VERSION = "4";

/** One palette entry: a menu name and the hex it stands for. */
export interface PaletteColor {
	name: string;
	hex: string;
}

/**
 * The whole settings model. Rendering is hex-only: the palette feeds the
 * menus, `legacy` keeps old ~={id} markup rendering (id to hex) until notes
 * are migrated with the convert commands.
 *
 * Invariant, established by `migrateSettings` and relied on everywhere
 * downstream: every `hex` and every `legacy` value is a canonical lowercase
 * hex color. A value that cannot be one is not stored.
 */
export interface FastTextColorPluginSettings {
	version: string;
	palette: PaletteColor[];
	/** id -> hex for markup written before the fork went hex-only */
	legacy: Record<string, string>;
	interactiveDelimiters: boolean;
	colorCodeSection: boolean;
}

export const DEFAULT_SETTINGS: FastTextColorPluginSettings = {
	version: SETTINGS_VERSION,
	palette: [
		{ name: "red", hex: "#e93147" },
		{ name: "orange", hex: "#ec7500" },
		{ name: "yellow", hex: "#e0ac00" },
		{ name: "green", hex: "#08b94e" },
		{ name: "cyan", hex: "#00bfbc" },
		{ name: "blue", hex: "#086ddd" },
		{ name: "purple", hex: "#7852ee" },
		{ name: "pink", hex: "#d53984" },
	],
	legacy: {},
	interactiveDelimiters: true,
	colorCodeSection: false,
};

/** Fallbacks for obsidian's palette variables when they cannot be resolved. */
export const VAR_FALLBACKS: Record<string, string> = {
	"--color-red": "#e93147",
	"--color-orange": "#ec7500",
	"--color-yellow": "#e0ac00",
	"--color-green": "#08b94e",
	"--color-cyan": "#00bfbc",
	"--color-blue": "#086ddd",
	"--color-purple": "#7852ee",
	"--color-pink": "#d53984",
};

/** color-1, color-2, ... skipping names that are already taken. */
export function nextFreeName(palette: PaletteColor[]): string {
	let n = palette.length + 1;
	while (palette.some(c => c.name === `color-${n}`)) {
		n++;
	}
	return `color-${n}`;
}

// --------------------------------------------------------------------------
//                              migration
// --------------------------------------------------------------------------

interface V3Color {
	id: string;
	color: string;
	useCssColorVariable?: boolean;
	colorVariable?: string;
}

interface V3Theme {
	name: string;
	colors: V3Color[];
}

/** What a migration had to leave behind, for the caller to report. */
export interface MigrationResult {
	settings: FastTextColorPluginSettings;
	/** color ids dropped because their value is not a color */
	dropped: string[];
}

/**
 * Bring any stored shape up to the current model. Pure: the environment
 * answers css lookups (the live document in the app, a table in tests).
 *
 * v3 and earlier had named colors grouped into themes, and stored whatever
 * css color string the user typed. The active theme becomes the palette;
 * every id of every theme lands in the legacy map so old markup keeps
 * rendering. Every value is resolved to a hex on the way in — a color that
 * cannot be expressed as a hex is dropped rather than stored, because a
 * stored non-hex renders but can never be converted, and would sit in the
 * settings forever pretending to be migratable.
 */
export function migrateSettings(raw: unknown, env: ColorEnvironment): MigrationResult {
	if (raw == null || typeof raw != "object") {
		return { settings: structuredClone(DEFAULT_SETTINGS), dropped: [] };
	}

	const record = raw as Record<string, unknown>;
	const dropped: string[] = [];

	const toggles = {
		interactiveDelimiters: record.interactiveDelimiters !== false,
		colorCodeSection: record.colorCodeSection === true,
	};

	if (record.version === SETTINGS_VERSION) {
		return {
			settings: {
				version: SETTINGS_VERSION,
				palette: sanitizePalette(record.palette, env, dropped),
				legacy: sanitizeLegacy(record.legacy, env, dropped),
				...toggles,
			},
			dropped,
		};
	}

	const hexOf = (color: V3Color): string | null => {
		const raw = color.useCssColorVariable && color.colorVariable
			? (env.variable(color.colorVariable) || VAR_FALLBACKS[color.colorVariable] || "")
			: (color.color ?? "");
		const hex = parseHex(raw) ?? env.toHex(raw);
		if (hex == null) {
			dropped.push(color.id);
		}
		return hex;
	};

	// v1/2 stored a flat `colors` array, v3 stored `themes`.
	const themes: V3Theme[] = Array.isArray(record.themes)
		? record.themes as V3Theme[]
		: [{ name: "default", colors: (record.colors as V3Color[] | undefined) ?? [] }];

	const themeIndex = typeof record.themeIndex == "number" ? record.themeIndex : 0;
	const active = themes[themeIndex] ?? themes[0];

	// active theme first so its ids win on collision.
	const legacy: Record<string, string> = {};
	for (const theme of [active, ...themes.filter(t => t !== active)]) {
		for (const color of theme?.colors ?? []) {
			if (color?.id != undefined && !(color.id in legacy)) {
				const hex = hexOf(color);
				if (hex != null) {
					legacy[color.id] = hex;
				}
			}
		}
	}

	const named = new Set<string>();
	const palette: PaletteColor[] = [];
	for (const color of active?.colors ?? []) {
		if (color?.id == undefined || legacy[color.id] == undefined || named.has(color.id)) {
			continue;
		}
		named.add(color.id);
		palette.push({ name: color.id, hex: legacy[color.id] });
	}

	return {
		settings: {
			version: SETTINGS_VERSION,
			palette: palette.length > 0 ? palette : structuredClone(DEFAULT_SETTINGS.palette),
			legacy,
			...toggles,
		},
		dropped,
	};
}

/** A hand edited data.json must not smuggle non-colors past the boundary. */
function sanitizePalette(raw: unknown, env: ColorEnvironment, dropped: string[]): PaletteColor[] {
	if (!Array.isArray(raw)) {
		return structuredClone(DEFAULT_SETTINGS.palette);
	}

	const palette: PaletteColor[] = [];
	for (const entry of raw) {
		const name = (entry as PaletteColor)?.name;
		if (typeof name != "string" || name === "") {
			continue;
		}
		const hex = parseHex((entry as PaletteColor)?.hex) ?? env.toHex(String((entry as PaletteColor)?.hex ?? ""));
		if (hex == null) {
			dropped.push(name);
			continue;
		}
		palette.push({ name, hex });
	}
	return palette;
}

function sanitizeLegacy(raw: unknown, env: ColorEnvironment, dropped: string[]): Record<string, string> {
	if (typeof raw != "object" || raw == null || Array.isArray(raw)) {
		return {};
	}

	const legacy: Record<string, string> = {};
	for (const [id, value] of Object.entries(raw as Record<string, unknown>)) {
		const hex = parseHex(value) ?? env.toHex(String(value ?? ""));
		if (hex == null) {
			dropped.push(id);
			continue;
		}
		legacy[id] = hex;
	}
	return legacy;
}
