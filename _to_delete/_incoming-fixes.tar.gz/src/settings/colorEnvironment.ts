import { parseHex } from "src/color/InlineColor";

/**
 * The outside world a settings migration needs: what obsidian's theme
 * variables currently hold, and what an arbitrary css color expression is
 * worth as a hex. Passed in rather than reached for, so migration stays pure
 * and testable.
 */
export interface ColorEnvironment {
	/** The raw value of a css custom property on the document body, or "". */
	variable(name: string): string;
	/** Any css color expression (`red`, `rgb(1,2,3)`, `#abc`) as a hex, or null. */
	toHex(css: string): string | null;
}

/** The live document as the authority. */
export function documentColorEnvironment(): ColorEnvironment {
	return {
		variable(name) {
			return activeWindow.getComputedStyle(activeDocument.body).getPropertyValue(name).trim();
		},
		toHex(css) {
			const direct = parseHex(css);
			if (direct != null) {
				return direct;
			}
			return computeHex(css);
		},
	};
}

/**
 * Ask the browser what a css color expression resolves to. Anything the
 * browser refuses to parse as a color is not a color, and does not become a
 * stored setting.
 */
function computeHex(css: string): string | null {
	if (!css) {
		return null;
	}

	const probe = activeDocument.createElement("span");
	probe.style.color = css;
	if (probe.style.color === "") {
		return null; // rejected by the css parser
	}

	probe.style.display = "none";
	activeDocument.body.appendChild(probe);
	try {
		return rgbToHex(activeWindow.getComputedStyle(probe).color);
	} finally {
		probe.remove();
	}
}

const RGB = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.]+%?))?\s*\)$/i;

/** `rgb(255, 136, 0)` -> `#ff8800`, keeping a non opaque alpha channel. */
export function rgbToHex(computed: string): string | null {
	const m = RGB.exec(computed.trim());
	if (m == null) {
		return null;
	}

	const byte = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
	const base = `#${byte(+m[1])}${byte(+m[2])}${byte(+m[3])}`;

	if (m[4] == undefined) {
		return base;
	}
	const alpha = m[4].endsWith("%") ? parseFloat(m[4]) / 100 : parseFloat(m[4]);
	return alpha >= 1 ? base : base + byte(alpha * 255);
}
