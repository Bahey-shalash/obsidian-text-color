import {
	Editor,
	MarkdownView,
	Menu,
	Notice,
	Plugin,
	TFile,
} from 'obsidian';
import { Prec, Compartment } from "@codemirror/state";
import { keymap, EditorView } from '@codemirror/view';

import { DEFAULT_SETTINGS, FastTextColorPluginSettings, migrateSettings, SETTINGS_VERSION } from 'src/settings/settings';
import { documentColorEnvironment } from 'src/settings/colorEnvironment';
import { FastTextColorPluginSettingTab } from 'src/settings/SettingsTab';
import { convertIdsToHex } from 'src/color/ConvertIds';
import { makeIdResolver } from 'src/color/resolveToken';
import { textColorParserField } from 'src/editor/TextColorStateField';
import { textColorViewPlugin } from 'src/editor/TextColorViewPlugin';
import { autoHexify } from 'src/editor/AutoHexify';
import { settingsFacet } from 'src/editor/SettingsFacet';
import { insertColor, removeColor, jumpOutOfColor } from 'src/editor/TextColorFunctions';
import { textColorPostProcessor } from 'src/reading/TextColorPostProcessor';
import { ColorSuggestModal } from 'src/ui/ColorSuggestModal';
import { CustomColorModal } from 'src/ui/CustomColorModal';
import { confirmByModal } from 'src/ui/ConfirmationModal';

/**
 * Plugin shell: wires the editor extensions, the reading mode post processor,
 * commands, menus and settings together. The actual behavior lives in the
 * color/, editor/, reading/, syntax/ and ui/ modules.
 */
export default class FastTextColorPlugin extends Plugin {
	settings!: FastTextColorPluginSettings;

	/** hex of the color applied last, seeding "apply latest" and the picker. */
	private lastUsedHex!: string;

	private settingsCompartment!: Compartment;

	async onload() {
		await this.loadSettings();
		this.lastUsedHex = this.settings.palette[0]?.hex ?? "#ff0000";

		this.registerEditorExtension(textColorParserField);
		this.registerEditorExtension(textColorViewPlugin);
		this.registerEditorExtension(autoHexify);
		this.registerMarkdownPostProcessor((el, ctx) => textColorPostProcessor(el, ctx, this.settings), -1000);

		// makes the settings available inside the editor extensions.
		this.settingsCompartment = new Compartment();
		this.registerEditorExtension(this.settingsCompartment.of(settingsFacet.of(this.settings)));

		this.registerEditorExtension(
			Prec.high(keymap.of([{
				key: "Tab",
				run: (view) => {
					const editor = this.app.workspace.getActiveViewOfType(MarkdownView)?.editor;
					return editor ? jumpOutOfColor(view, editor) : false;
				},
			}]))
		);

		this.registerCommands();
		this.registerContextMenu();
		this.addSettingTab(new FastTextColorPluginSettingTab(this.app, this));
	}

	// ----------------------------------------------------------------------
	//                              commands
	// ----------------------------------------------------------------------

	private registerCommands(): void {
		this.addCommand({
			id: 'change-text-color',
			name: 'Change text color',
			editorCallback: (editor: Editor) => this.openSuggester(editor),
		});

		this.addCommand({
			id: 'apply-custom-color',
			name: 'Apply custom color (hex)',
			editorCallback: (editor: Editor) => this.openCustomPicker(editor),
		});

		this.addCommand({
			id: 'text-color-latestcolor',
			name: 'Apply latest color',
			editorCallback: (editor: Editor) => insertColor(this.lastUsedHex, editor),
		});

		this.addCommand({
			id: 'remove-text-color',
			name: 'Remove text color',
			editorCallback: (editor, view) => {
				const editorView = editorViewOf(view);
				if (editorView) {
					removeColor(editor, editorView);
				}
			},
		});

		this.addCommand({
			id: 'convert-ids-to-hex-note',
			name: 'Convert color ids to hex (current note)',
			callback: async () => {
				const file = this.app.workspace.getActiveFile();
				if (!file) {
					new Notice("No active note.");
					return;
				}
				const { converted, skipped } = await this.convertIdsInFile(file);
				new Notice(`${file.basename}: ${converted} id(s) converted${keptSuffix(skipped)}.`);
			},
		});

		this.addCommand({
			id: 'convert-ids-to-hex-vault',
			name: 'Convert color ids to hex (entire vault)',
			callback: () => this.convertIdsInVault(),
		});
	}

	private registerContextMenu(): void {
		this.registerEvent(
			this.app.workspace.on("editor-menu", (menu, editor, view) => {
				if (editor.getSelection() == '') {
					return;
				}
				menu.addItem((item) => {
					item.setSection("selection")
						.setTitle("Color")
						.setIcon("palette");
					// @ts-ignore setSubmenu is not in the public api
					const submenu: Menu = item.setSubmenu();

					this.settings.palette.forEach(color => {
						submenu.addItem((subitem) => {
							subitem.setTitle(color.name)
								.setIcon("circle")
								.onClick(() => this.applyColor(color.hex, editor));
						});
					});

					submenu.addItem((subitem) => {
						subitem.setTitle("Custom...")
							.setIcon("pipette")
							.onClick(() => this.openCustomPicker(editor));
					});

					submenu.addItem((subitem) => {
						subitem.setTitle("remove")
							.setIcon("ban")
							.onClick(() => {
								const editorView = editorViewOf(view);
								if (editorView) {
									removeColor(editor, editorView);
								}
							});
					});
				});
			})
		);
	}

	private applyColor(hex: string, editor: Editor): void {
		this.lastUsedHex = hex;
		insertColor(hex, editor);
	}

	private openSuggester(editor: Editor): void {
		if (this.settings.palette.length == 0) {
			new Notice("The palette is empty. Add colors in the settings.");
			return;
		}
		new ColorSuggestModal(this.app, this.settings.palette, editor,
			(color) => { this.lastUsedHex = color.hex; }).open();
	}

	private openCustomPicker(editor: Editor): void {
		new CustomColorModal(this.app, editor, this.lastUsedHex,
			(hex) => { this.lastUsedHex = hex; }).open();
	}

	// ----------------------------------------------------------------------
	//                            id migration
	// ----------------------------------------------------------------------

	private async convertIdsInVault(): Promise<void> {
		const files = this.app.vault.getMarkdownFiles();
		if (!await confirmByModal(this.app,
			`Rewrite ~={id} color markup to hex in all ${files.length} markdown files. Make a backup or commit your vault first.`,
			"Convert entire vault?")) {
			return;
		}

		let converted = 0, skipped = 0, changedFiles = 0;
		for (const file of files) {
			const result = await this.convertIdsInFile(file);
			converted += result.converted;
			skipped += result.skipped;
			if (result.converted > 0) {
				changedFiles++;
			}
		}
		new Notice(`Converted ${converted} id(s) in ${changedFiles} note(s)${keptSuffix(skipped)}.`);
	}

	/** Rewrite ~={id} markup in one file to the hex the id resolves to. */
	private async convertIdsInFile(file: TFile): Promise<{ converted: number, skipped: number }> {
		const resolve = makeIdResolver(this.settings);

		let converted = 0, skipped = 0;
		await this.app.vault.process(file, (data) => {
			const result = convertIdsToHex(data, resolve);
			converted = result.converted;
			skipped = result.skipped;
			return result.text;
		});
		return { converted, skipped };
	}

	// ----------------------------------------------------------------------
	//                          settings plumbing
	// ----------------------------------------------------------------------

	async loadSettings() {
		const raw = await this.loadData();
		const { settings, dropped } = migrateSettings(raw ?? DEFAULT_SETTINGS, documentColorEnvironment());
		this.settings = settings;

		if (dropped.length > 0) {
			console.warn(`fast-text-color: dropped ${dropped.length} setting(s) whose value is not a color: ${dropped.join(", ")}`);
		}

		if ((raw as { version?: string } | null)?.version !== SETTINGS_VERSION || dropped.length > 0) {
			await this.saveData(this.settings);
		}
	}

	/**
	 * The only way settings change. A new object replaces the old one, which
	 * is what makes the change visible to every editor: the facet compares by
	 * identity, so an in place edit would be invisible to it.
	 */
	async updateSettings(update: Partial<FastTextColorPluginSettings>): Promise<void> {
		this.settings = { ...this.settings, ...update };
		await this.saveData(this.settings);
		this.refreshViews();
	}

	/** Push the current settings into every open markdown view, not just the active one. */
	private refreshViews(): void {
		this.app.workspace.getLeavesOfType("markdown").forEach(leaf => {
			const view = leaf.view as MarkdownView;

			editorViewOf(view)?.dispatch({
				effects: this.settingsCompartment.reconfigure(settingsFacet.of(this.settings)),
			});

			// reading mode renders once and keeps the result; it has to be
			// asked to render again with the new settings.
			if (view.getMode?.() === "preview") {
				view.previewMode?.rerender(true);
			}
		});
	}
}

/** How many ids a conversion left alone, as a notice suffix. */
function keptSuffix(skipped: number): string {
	return skipped ? `, ${skipped} kept (unknown names)` : "";
}

/** The underlying CodeMirror view of a markdown view; not in the public api. */
function editorViewOf(view: MarkdownView | { editor?: Editor } | null): EditorView | null {
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- editor.cm is not in the public api
	return ((view?.editor as any)?.cm as EditorView) ?? null;
}
