import type { ColorEnvironment } from "src/settings/colorEnvironment";

/**
 * A table backed stand-in for the live document, so migration tests never
 * need a browser. Anything not in a table is not a color.
 */
export function fakeEnvironment(
	variables: Record<string, string> = {},
	colors: Record<string, string> = {},
): ColorEnvironment {
	return {
		variable: name => variables[name] ?? "",
		toHex: css => colors[css] ?? null,
	};
}
