import { migrateSettings, DEFAULT_SETTINGS, SETTINGS_VERSION } from "src/settings/settings";
import { fakeEnvironment } from "./support/colorEnvironment";
// the user's real pre-migration data.json, as a regression fixture
import * as v3 from "./fixtures/data-v3.json";

const env = fakeEnvironment(
	{ "--color-red": "#fb464c" },
	{ "red": "#ff0000", "rgb(0, 128, 0)": "#008000" },
);

describe("migrateSettings from the real v3 data.json", () => {
	const { settings: migrated, dropped } = migrateSettings(v3, env);

	test("lands on the current version", () => {
		expect(migrated.version).toBe(SETTINGS_VERSION);
	});

	test("the active theme becomes the palette", () => {
		expect(migrated.palette.map(c => c.name)).toEqual(
			["red", "orange", "yellow", "green", "cyan", "blue", "purple", "pink"]);
	});

	test("variable colors resolve through the environment, else the fallback table", () => {
		expect(migrated.palette.find(c => c.name == "red")?.hex).toBe("#fb464c"); // resolved
		expect(migrated.palette.find(c => c.name == "green")?.hex).toBe("#08b94e"); // fallback
	});

	test("every id of every theme lands in the legacy map, active theme first", () => {
		expect(migrated.legacy["red"]).toBe("#fb464c");      // builtin red, not default #ff0000
		expect(migrated.legacy["magenta"]).toBe("#ff00ff");  // only in the default theme
		expect(migrated.legacy["black"]).toBe("#000000");
	});

	test("toggles survive", () => {
		expect(migrated.interactiveDelimiters).toBe(true);
		expect(migrated.colorCodeSection).toBe(v3.colorCodeSection);
	});

	test("nothing has to be dropped", () => {
		expect(dropped).toEqual([]);
	});
});

describe("migrateSettings edge cases", () => {
	test("null and garbage yield the defaults", () => {
		expect(migrateSettings(null, env).settings).toEqual(DEFAULT_SETTINGS);
		expect(migrateSettings("junk", env).settings).toEqual(DEFAULT_SETTINGS);
	});

	test("current version passes through with defaults filled in", () => {
		const v4 = { version: SETTINGS_VERSION, palette: [{ name: "x", hex: "#123456" }] };
		const out = migrateSettings(v4, env).settings;
		expect(out.palette).toEqual([{ name: "x", hex: "#123456" }]);
		expect(out.legacy).toEqual({});
	});

	test("v1/v2 flat colors become palette and legacy", () => {
		const v1 = { version: "1", colors: [{ id: "warn", color: "#FFAA00" }] };
		const out = migrateSettings(v1, env).settings;
		expect(out.palette).toEqual([{ name: "warn", hex: "#ffaa00" }]);
		expect(out.legacy).toEqual({ warn: "#ffaa00" });
	});
});

/**
 * The settings must never hold a value that renders but cannot be converted.
 * A css color name is resolved to a hex on the way in; anything the
 * environment does not recognise as a color does not become a setting.
 */
describe("everything stored is a hex", () => {
	test("css color names are resolved, not stored verbatim", () => {
		const v3Named = { version: "3", colors: [{ id: "warn", color: "red" }] };
		const out = migrateSettings(v3Named, env).settings;
		expect(out.palette).toEqual([{ name: "warn", hex: "#ff0000" }]);
		expect(out.legacy).toEqual({ warn: "#ff0000" });
	});

	test("rgb() is resolved too", () => {
		const v1 = { version: "1", colors: [{ id: "go", color: "rgb(0, 128, 0)" }] };
		expect(migrateSettings(v1, env).settings.legacy).toEqual({ go: "#008000" });
	});

	test("a value that is not a color at all is dropped and reported", () => {
		const v1 = { version: "1", colors: [{ id: "bad", color: "url(https://example.com/x.png)" }] };
		const { settings, dropped } = migrateSettings(v1, env);
		expect(settings.legacy).toEqual({});
		expect(dropped).toEqual(["bad"]);
	});

	test("a hand edited v4 data.json cannot smuggle a non-hex in", () => {
		const v4 = {
			version: SETTINGS_VERSION,
			palette: [
				{ name: "ok", hex: "#ABCDEF" },
				{ name: "sneaky", hex: "red; background-image: url(https://example.com/beacon)" },
				{ name: "", hex: "#000000" },
			],
			legacy: { good: "#0f8", bad: "inherit" },
		};
		const { settings, dropped } = migrateSettings(v4, env);

		expect(settings.palette).toEqual([{ name: "ok", hex: "#abcdef" }]);
		expect(settings.legacy).toEqual({ good: "#0f8" });
		expect(dropped).toEqual(expect.arrayContaining(["sneaky", "bad"]));
	});

	test("a legacy map that is an array is not a legacy map", () => {
		const v4 = { version: SETTINGS_VERSION, palette: [], legacy: ["#fff"] };
		expect(migrateSettings(v4, env).settings.legacy).toEqual({});
	});
});
