import { rgbToHex } from "src/settings/colorEnvironment";

/**
 * The browser answers every css color as `rgb()` / `rgba()`; this is how that
 * answer becomes a hex the settings may store.
 */
describe("rgbToHex", () => {
	test("opaque colors", () => {
		expect(rgbToHex("rgb(255, 136, 0)")).toBe("#ff8800");
		expect(rgbToHex("rgb(0,0,0)")).toBe("#000000");
		expect(rgbToHex("rgb(255 255 255)")).toBe("#ffffff");
	});

	test("an alpha channel survives", () => {
		expect(rgbToHex("rgba(255, 136, 0, 0.5)")).toBe("#ff880080");
		expect(rgbToHex("rgb(255 136 0 / 50%)")).toBe("#ff880080");
	});

	test("a fully opaque alpha is dropped", () => {
		expect(rgbToHex("rgba(255, 136, 0, 1)")).toBe("#ff8800");
	});

	test("anything that is not an rgb answer is not a color", () => {
		["", "transparent", "red", "#ff8800", "color(display-p3 1 0 0)"].forEach(value => {
			expect(rgbToHex(value)).toBe(null);
		});
	});
});
