import { convertIdsToHex } from "src/color/ConvertIds";
import { makeIdResolver } from "src/color/resolveToken";
import { DEFAULT_SETTINGS, FastTextColorPluginSettings } from "src/settings/settings";

describe("convertIdsToHex", () => {
	const resolve = (id: string) =>
		({ red: "#E93147", code: "#a6c25a" } as Record<string, string>)[id] ?? null;

	test("rewrites a known id and lowercases the hex", () => {
		const r = convertIdsToHex("a ~={red}text=~ b", resolve);
		expect(r.text).toBe("a ~={#e93147}text=~ b");
		expect(r).toMatchObject({ converted: 1, skipped: 0 });
	});

	test("leaves hex literals untouched", () => {
		const input = "~={#ff8800}x=~";
		const r = convertIdsToHex(input, resolve);
		expect(r.text).toBe(input);
		expect(r).toMatchObject({ converted: 0, skipped: 0 });
	});

	test("keeps unknown ids and counts them", () => {
		const input = "~={mystery}x=~";
		const r = convertIdsToHex(input, resolve);
		expect(r.text).toBe(input);
		expect(r).toMatchObject({ converted: 0, skipped: 1 });
	});

	test("handles several sections and keeps everything else byte for byte", () => {
		const input = "# H\n~={red}a=~ mid ~={code}b=~ and ~={#0f8}c=~\n\ttabs stay";
		const r = convertIdsToHex(input, resolve);
		expect(r.text).toBe("# H\n~={#e93147}a=~ mid ~={#a6c25a}b=~ and ~={#0f8}c=~\n\ttabs stay");
		expect(r).toMatchObject({ converted: 2, skipped: 0 });
	});

	test("nested sections convert independently", () => {
		const r = convertIdsToHex("~={red}out ~={code}in=~ side=~", resolve);
		expect(r.text).toBe("~={#e93147}out ~={#a6c25a}in=~ side=~");
	});
});

describe("makeIdResolver", () => {
	const settings: FastTextColorPluginSettings = {
		...structuredClone(DEFAULT_SETTINGS),
		palette: [{ name: "code", hex: "#a6c25a" }],
		legacy: { green: "#08b94e" },
	};

	test("resolves palette names and legacy ids, rejects the rest", () => {
		const resolve = makeIdResolver(settings);
		expect(resolve("code")).toBe("#a6c25a");
		expect(resolve("green")).toBe("#08b94e");
		expect(resolve("nope")).toBe(null);
	});

	/**
	 * "skipped" in a conversion notice means exactly one thing: the name is
	 * unknown. It used to also mean "known, but its value is not a hex", which
	 * made the notice a lie and the note unmigratable forever.
	 */
	test("every resolvable id converts, so skipped only ever means unknown", () => {
		const resolve = makeIdResolver(settings);
		const r = convertIdsToHex("~={code}a=~ ~={green}b=~ ~={ghost}c=~", resolve);
		expect(r.text).toBe("~={#a6c25a}a=~ ~={#08b94e}b=~ ~={ghost}c=~");
		expect(r).toMatchObject({ converted: 2, skipped: 1 });
	});
});
